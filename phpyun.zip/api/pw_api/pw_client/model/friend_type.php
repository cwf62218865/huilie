<?php
class friend_type {
 
}
?>