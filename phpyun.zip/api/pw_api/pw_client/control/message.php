<?php
class messagecontrol {
    
}
?>