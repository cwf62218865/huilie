<?php

/*
* $Author ��PHPYUN�����Ŷ�
*
* ����: http://www.phpyun.com
*
* ��Ȩ���� 2009-2017 ��Ǩ�γ���Ϣ�������޹�˾������������Ȩ����
*
* ����������δ����Ȩǰ���£�����������ҵ��Ӫ�����ο����Լ��κ���ʽ���ٴη�����
 */
class admin_announcement_controller extends common
{
	function set_search(){
		$ad_time=array('1'=>'����','3'=>'�������','7'=>'�������','15'=>'�������','30'=>'���һ����');
		$search_list[]=array("param"=>"end","name"=>'����ʱ��',"value"=>$ad_time);
		$this->yunset("search_list",$search_list);
	}
	function index_action(){
		$this->set_search();
		
		if(trim($_GET['keyword'])){
			$where="`title` like '%".trim($_GET['keyword'])."%'";
			$urlarr['keyword']=$_GET['keyword'];
		}else{
			$where=1;
		}
		if($_GET['end']){
			if($_GET['end']=='1'){
				$where.=" and `datetime` >= '".strtotime(date("Y-m-d 00:00:00"))."'";
			}else{
				$where.=" and `datetime` >= '".strtotime('-'.(int)$_GET['end'].'day')."'";
			}
			$urlarr['end']=$_GET['end'];
		}
		if($_GET['order'])
		{
			$where.=" order by ".$_GET['t']." ".$_GET['order'];
			$urlarr['order']=$_GET['order'];
			$urlarr['t']=$_GET['t'];
		}else{
			$where.=" order by id desc";
		}
		$urlarr['page']="{{page}}";
		$pageurl=Url($_GET['m'],$urlarr,'admin');
        $M=$this->MODEL();
		$announcement=$M->get_page("admin_announcement",$where,$pageurl,$this->config['sy_listnum'],'*','announcement');
		$this->yunset($announcement);
		$this->yuntpl(array('admin/admin_announcement_list'));
	}
	function add_action(){
		include PLUS_PATH."/domain_cache.php";
		$Dname[0] = '��վ';
		if(is_array($site_domain)){
			foreach($site_domain as $key=>$value){
				$Dname[$value['id']]  =  $value['webname'];
			}
		}
		$this->yunset("Dname", $Dname);
		if($_GET['id']){
			$info = $this->obj->DB_select_once("admin_announcement","`id`='".$_GET['id']."'");
			$info['content']=str_replace("&","&amp;",$info['content']);
			$this->yunset("info",$info);
			$this->yunset("lasturl",$_SERVER['HTTP_REFERER']);
		}
        $this->yuntpl(array('admin/admin_announcement_add'));
	}

	function save_action(){
		if($_POST['update']){
			$time = time();
			if($_POST['did']==""){
				$_POST['did']=0;
			}
			$value.="`did`='".$_POST['did']."',";
			$value.="`title`='".$_POST['title']."',";
			$value.="`datetime`='$time',";
			$value.="`keyword`='".$_POST['keyword']."',";
			$value.="`description`='".$_POST['description']."',";
			$content = str_replace("&amp;","&",html_entity_decode($_POST['content'],ENT_QUOTES,"GB2312"));
			$value.="`content`='".$content."'";
			$nbid=$this->obj->DB_update_all("admin_announcement",$value,"`id`='".$_POST['id']."'");
			$lasturl=str_replace("&amp;","&",$_POST['lasturl']);
			isset($nbid)?$this->ACT_layer_msg("����(ID:".$_POST['id'].")���³ɹ���",9,$lasturl,2,1):$this->ACT_layer_msg("����ʧ�ܣ�",8,$lasturl,2,1);
		}
	    if($_POST['add']){
			$time = time();
			if($_POST['did']==""){
				$_POST['did']=0;
			}
			$value.="`did`='".$_POST['did']."',";
			$value.="`title`='".$_POST['title']."',";
			$value.="`datetime`='$time',";
			$value.="`keyword`='".$_POST['keyword']."',";
			$value.="`description`='".$_POST['description']."',";
			$content = str_replace("&amp;","&",html_entity_decode($_POST['content'],ENT_QUOTES,"GB2312"));
			$value.="`content`='".$content."'";
			$nbid=$this->obj->DB_insert_once("admin_announcement",$value);
			isset($nbid)?$this->ACT_layer_msg("����(ID:".$nbid.")���ӳɹ���",9,"index.php?m=admin_announcement",2,1):$this->ACT_layer_msg("����ʧ�ܣ�",8,"index.php?m=admin_announcement",2,1);
		}
	}
	function del_action(){
		$this->check_token();
	    if($_GET['del']){

	    	$del=$_GET['del'];
	    	if($del){
	    		if(is_array($del)){
					$this->obj->DB_delete_all("admin_announcement","`id` in(".@implode(',',$del).")","");
			    }else{
	    		 	$this->obj->DB_delete_all("admin_announcement","`id`='$del'");
	    		}
				$this->layer_msg('����(ID:'.@implode(',',$del).')ɾ���ɹ���',9,1,$_SERVER['HTTP_REFERER']);
			}else{
				$this->layer_msg('��ѡ����Ҫɾ���Ĺ��棡',8,1,$_SERVER['HTTP_REFERER']);
	    	}
	    }
	    if(isset($_GET['id'])){
			$where="`id`='".$_GET['id']."'";
			$result=$this->obj->DB_delete_all("admin_announcement", $where);
			isset($result)?$this->layer_msg('����(ID:'.$_GET['id'].')ɾ���ɹ���',9,0,$_SERVER['HTTP_REFERER']):$this->layer_msg('ɾ��ʧ�ܣ�',8,0,$_SERVER['HTTP_REFERER']);
		}else{
			$this->layer_msg('�Ƿ�������',8,0,$_SERVER['HTTP_REFERER']);
		}
	}
}
?>